/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.egsalas.prueba.neubox;

import java.io.IOException;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.egsalas.prueba.neubox.storage.StorageFileNotFoundException;
import com.egsalas.prueba.neubox.storage.StorageService;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;

/**
 *
 * @author egsal
 */
@Controller
public class uploadController {
    
    private StorageService storageService;

    @Autowired
    public void FileUploadController(StorageService storageService) {
            this.storageService = storageService;
    }
    
    @ApiResponses(value = { @ApiResponse(code = 200, message = "OK"), @ApiResponse(code = 400, message = "Objeto JSON malformado") })
    @CrossOrigin(origins="*")
    @PostMapping("/upload")
    public ResponseEntity<Map<String, String>> handleFileUpload(@RequestParam("file") MultipartFile file) {

            storageService.store(file);
            
            /* Leyendo contenido de archivo */
            int lineCounter=0;
            int rounds=0;
            Map<String, int[]> points = new HashMap<>();
            Map<String, String> result = new HashMap<>();
            try{
                InputStreamReader isr=new InputStreamReader(file.getInputStream());
                BufferedReader br=new BufferedReader(isr);
                String line;
                
                while((line=br.readLine())!=null){
                    if(lineCounter==0){
                        rounds=Integer.parseInt(line);
                    }
                    String [] pts=line.split(" ");
                    int []intPts=new int[2];
                    intPts[0]=Integer.parseInt(pts[0]);
                    intPts[1]=Integer.parseInt(pts[1]);
                    points.put(""+lineCounter,intPts);
                    lineCounter++;
                }
                if(rounds!=result.size()){
                    result.put("message", "El número de rondas no coincide con el especificado");
                    return new ResponseEntity<Map<String, String>>(result ,HttpStatus.BAD_REQUEST);
                }
                int winner=0;
                int lastTopPoints=0;
                for(int i=0;i<result.size();i++){
                    int values[]=points.get(""+i);
                    int diff=values[0]-values[1];
                    int w=(diff>0)?1:0;
                    int absDiff=Math.abs(w);
                    if(absDiff>lastTopPoints){
                        winner=w;
                        lastTopPoints=absDiff;
                    }
                }
                result.put("result","{winner:"+winner+",points:"+lastTopPoints);
            }
            catch(IOException | NumberFormatException | ArrayIndexOutOfBoundsException e){
                result.put("message", e.getMessage());
                return new ResponseEntity<Map<String, String>>(result ,HttpStatus.BAD_REQUEST);
            }
            
            return new ResponseEntity<Map<String, String>>(result ,HttpStatus.OK);
    }

    @ExceptionHandler(StorageFileNotFoundException.class)
    public ResponseEntity<?> handleStorageFileNotFound(StorageFileNotFoundException exc) {
            return ResponseEntity.notFound().build();
    }
}
